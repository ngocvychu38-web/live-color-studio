#include <bnb/glsl.frag>

#define PRIMARY_INTENSITY 1.3
#define PRIMARY_CONCENTRATION 2.0
#define SECONDARY_INTENSITY 5.0
#define SECONDARY_CONCENTRATION 0.3
#define LIGHT_DIR normalize(vec3(0.5, 0.3, 0.8))
#define PW_SCALER bnb_SCREEN.x + bnb_SCREEN.y

vec2 noise(vec3 x, BNB_DECLARE_SAMPLER_2D_ARGUMENT(tex_noise))
{
    vec3 p = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.f - 2.f * f);
    vec2 uv = (p.xy + vec2(37.f, 17.f) * p.z) + f.xy;
    vec4 rg = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_noise), (uv + 0.5f) / 256.f);
    return mix(rg.yw, rg.xz, f.z);
}

// Based on TekF's "Anisotropic Highlights" (https://www.shadertoy.com/view/XdB3DG)
float glitter(vec3 pos, vec3 rd, vec3 normal, vec3 ligt, BNB_DECLARE_SAMPLER_2D_ARGUMENT(tex_noise))
{
    float nl = dot(normal, ligt);
    vec3 h = normalize(ligt - rd);

    vec3 coord = pos * 0.5f;
    coord.xy = coord.xy * 0.7071f + coord.yx * 0.7071f * vec2(1.f, -1.f);
    coord.xz = coord.xz * 0.7071f + coord.zx * 0.7071f * vec2(1.f, -1.f);
    vec3 coord2 = coord;

// displacement of the noise grabs to create the glinting effect
#if 1
    vec3 ww = fwidth(pos);
    coord.xy -= h.xz * 20.f * ww.xy;
    coord.xz -= h.xy * 20.f * ww.xz;
    coord2.xy -= h.xy * 5.f * ww.xy;
    coord2.xz -= h.xz * 5.f * ww.xz;
#endif

    // first layer (inner glints)
    float pw = 0.21f * PW_SCALER;
    vec3 aniso = vec3(noise(coord * pw, BNB_PASS_SAMPLER_ARGUMENT(tex_noise)), noise(coord.yzx * pw, BNB_PASS_SAMPLER_ARGUMENT(tex_noise)).x) * 2.f - 1.f;
    aniso -= normal * dot(aniso, normal);
    float anisotropy = min(1.f, length(aniso));
    aniso /= anisotropy;
    anisotropy = 0.55f;
    float ah = abs(dot(h, aniso));
    float nh = abs(dot(normal, h));
    float q = exp2((1.1f - anisotropy) * 3.5f);
    nh = pow(nh, q * PRIMARY_CONCENTRATION);
    nh *= pow(1.f - ah * anisotropy, 10.f);
    float glints = nh * exp2((1.2f - anisotropy) * PRIMARY_INTENSITY);
    glints *= smoothstep(0.f, 0.5f, nl);

    // second layer (outer glints)
    pw = 0.145f * PW_SCALER;
    vec3 aniso2 = vec3(noise(coord2 * pw, BNB_PASS_SAMPLER_ARGUMENT(tex_noise)), noise(coord2.yzx * pw, BNB_PASS_SAMPLER_ARGUMENT(tex_noise)).x) * 2.f - 1.f;
    anisotropy = 0.6f;
    float ah2 = abs(dot(h, aniso2));
    float q2 = exp2((0.1f - anisotropy) * 3.5f);
    float nh2 = pow(nh, q2 * SECONDARY_CONCENTRATION);
    nh2 *= pow(1.f - ah2 * anisotropy, 150.f);
    float glints2 = nh2 * ((1.f - anisotropy) * SECONDARY_INTENSITY);
    glints2 *= smoothstep(0.f, 0.4f, nl);

    return glints + glints2;
}

vec3 glitter_area(vec3 background, vec3 glitter_color, float alpha, vec3 N, BNB_DECLARE_SAMPLER_2D_ARGUMENT(tex_noise), vec3 var_v)
{
    vec4 color_alpha = vec4(background, 0.f);

    float glitter_intensity = glitter(var_v * 0.01f, vec3(0.f, 0.f, -1.f), N, LIGHT_DIR, BNB_PASS_SAMPLER_ARGUMENT(tex_noise)) * alpha;
    color_alpha.rgb += glitter_intensity * glitter_color.rgb;
    color_alpha.a = glitter_intensity;

    return mix(background, color_alpha.rgb, color_alpha.a);
}
