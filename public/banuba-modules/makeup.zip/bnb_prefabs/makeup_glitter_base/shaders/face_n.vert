#include <bnb/glsl.vert>

layout(location = 0) in vec3 attrib_pos;
layout(location = 1) in vec3 attrib_pos_static;
layout(location = 2) in vec2 attrib_uv;
layout(location = 3) in vec4 attrib_red_mask;

BNB_OUT(0)
vec3 var_v;

void main()
{
    gl_Position = bnb_MVP * vec4(attrib_pos, 1.);
    var_v = (bnb_MV * vec4(attrib_pos, 1.)).xyz;
}
