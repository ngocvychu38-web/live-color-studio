#include <bnb/glsl.frag>

BNB_IN(0)
vec3 var_v;

void main()
{
#if defined(BNB_VK_1)
    vec3 n = normalize(cross(dFdx(var_v), -dFdy(var_v)));
#else
    vec3 n = normalize(cross(dFdx(var_v), dFdy(var_v)));
#endif
    bnb_FragColor = vec4(n * 0.5 + 0.5, 1.);
}
