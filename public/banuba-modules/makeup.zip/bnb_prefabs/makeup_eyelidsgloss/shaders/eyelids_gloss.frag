#include <bnb/glsl.frag>

BNB_IN(0)
vec2 var_uv;

BNB_IN(1)
vec2 var_gloss_uv;

BNB_DECLARE_SAMPLER_2D(0, 1, eyeshadows_result);
BNB_DECLARE_SAMPLER_2D(2, 3, eyeshadows_smokey);
BNB_DECLARE_SAMPLER_2D(4, 5, eyelids_gloss_mask);

void main()
{
    vec4 camera_eyeshadows = BNB_TEXTURE_2D(BNB_SAMPLER_2D(eyeshadows_result), var_uv);
    vec4 smokey = BNB_TEXTURE_2D(BNB_SAMPLER_2D(eyeshadows_smokey), var_uv);
    vec4 gloss_mask = BNB_TEXTURE_2D(BNB_SAMPLER_2D(eyelids_gloss_mask), var_gloss_uv);

    float smokey_mask = min(1.f, smokey.r + smokey.g + smokey.b);
    gloss_mask.x *= smokey_mask;

    float max_brightness_param = eyelids_gloss_params.x;
    float multiplier_param = eyelids_gloss_params.y;
    float alpha_param = eyelids_gloss_params.z;

    float V = max_brightness_param * multiplier_param / 255.f;
    V = min(1.f, V);

    vec3 result = camera_eyeshadows.rgb;

    result.x = result.x * (1.f - gloss_mask.x) + gloss_mask.x * V;
    result.y = result.y * (1.f - gloss_mask.x) + gloss_mask.x * V;
    result.z = result.z * (1.f - gloss_mask.x) + gloss_mask.x * V;

    result = result * alpha_param + camera_eyeshadows.rgb * (1.f - alpha_param);

    bnb_FragColor = vec4(result, 1.f);
}
