#include <bnb/glsl.frag>
#include "bnb_prefabs/makeup_glitter_base/shaders/glitter.glsl"

BNB_IN(0)
vec2 var_bg_uv;
BNB_IN(1)
vec2 var_lips_uv;
BNB_IN(2)
vec3 var_v;

BNB_DECLARE_SAMPLER_2D(0, 1, camera);
BNB_DECLARE_SAMPLER_2D(2, 3, normalmap);
BNB_DECLARE_SAMPLER_2D(4, 5, lips_nn);
BNB_DECLARE_SAMPLER_2D(6, 7, tex_noise);

#define FLT_EPSILON 0.004f // 1.f/255

void main()
{
    vec3 background = texelFetch(BNB_SAMPLER_2D(camera), ivec2(gl_FragCoord.xy), 0).rgb;
    float mask_alpha = BNB_TEXTURE_2D(BNB_SAMPLER_2D(lips_nn), var_lips_uv).x;
    float alpha = lips_glitter_color_alpha.a * mask_alpha;

    if (alpha > FLT_EPSILON) {
        vec3 N = normalize(texture(BNB_SAMPLER_2D(normalmap), var_bg_uv).xyz * 2.f - 1.f);
        vec3 result = glitter_area(background, lips_glitter_color_alpha.rgb, alpha, N, BNB_PASS_SAMPLER_ARGUMENT(tex_noise), var_v);
        bnb_FragColor = vec4(result, 1.f);
        return;
    }

    bnb_FragColor = vec4(background, 1.f);
}
