'use strict';

const prefabs = require("bnb_js/prefabs");
const default_threshold = 0.95;
const default_contour = 0.5;
const default_weakness = 0.5;
const default_multiplier = 1.5;
const default_alpha = 0.7;

class MakeupLipsgloss extends prefabs.Base {
    constructor(faceIndex=0) {
        super(faceIndex);

        this.params = new bnb.FeatureParameter(default_threshold, default_contour, default_weakness);

        /* send those params to cpu (Don't send them from JS directly to gpu).
         Later cpu will send them to gpu. It helps to sync changes of params and masks on gpu. */
        this.gpu_params = new bnb.FeatureParameter(default_multiplier, default_alpha, 0.0, 0.0);
    }
    
    threshold(value) {
        this.params.x = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.LIPS_GLOSS, [this.params, this.gpu_params]);
    }
    
    contour(value) {
        this.params.y = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.LIPS_GLOSS, [this.params, this.gpu_params]);
    }
    
    weakness(value) {
        this.params.z = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.LIPS_GLOSS, [this.params, this.gpu_params]);
    }

    multiplier(value) {
        this.gpu_params.x = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.LIPS_GLOSS, [this.params, this.gpu_params]);
    }
    
    alpha(value) {
        this.gpu_params.y = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.LIPS_GLOSS, [this.params, this.gpu_params]);
    }
    
    clear() {
        this.params.x = default_threshold;
        this.params.y = default_contour;
        this.params.z = default_weakness;
        this.gpu_params.x = default_multiplier;
        this.gpu_params.y = default_alpha;
        bnb.scene.addFeatureParam(bnb.FeatureID.LIPS_GLOSS, [this.params, this.gpu_params]);
    }
}

exports = {
    MakeupLipsgloss
}
