#include <bnb/glsl.frag>

BNB_IN(0)
vec2 var_uv;

BNB_IN(1)
vec2 var_chameleon_uv;

BNB_DECLARE_SAMPLER_2D(0, 1, tex_lipschameleon_color_0);
BNB_DECLARE_SAMPLER_2D(2, 3, tex_lipschameleon_color_1);
BNB_DECLARE_SAMPLER_2D(4, 5, tex_lipschameleon);

void main()
{
    vec4 color_0 = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_lipschameleon_color_0), var_uv);
    vec4 color_1 = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_lipschameleon_color_1), var_uv);
    float lipsgloss = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_lipschameleon), var_chameleon_uv).x;

    vec4 result = mix(color_0, color_1, lipsgloss);

    bnb_FragColor = vec4(result.rgb, 1.f);
}
