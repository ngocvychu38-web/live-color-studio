#include <bnb/glsl.vert>
#include <bnb/matrix_operations.glsl>

BNB_LAYOUT_LOCATION(0)
BNB_IN vec2 attrib_pos;

BNB_OUT(0)
vec2 var_uv;

BNB_OUT(1)
vec2 var_chameleon_uv;

void main()
{
    /* upscale mesh and uv to avoid the situation, when mesh cuts edges of eyeshadows */
    float mask_mesh_scaler = 1.25f;
    var_chameleon_uv = mask_mesh_scaler * attrib_pos * 0.5 + 0.5;

    mat3 nn_mat = mat3(eyelids_chameleon_nn_transform[0].xyz, eyelids_chameleon_nn_transform[1].xyz, eyelids_chameleon_nn_transform[2].xyz);
    gl_Position = vec4((vec3(var_chameleon_uv, 1.f) * bnb_inverse_trs2d(nn_mat)).xy, 0.f, 1.f);
    var_uv = gl_Position.xy * 0.5f + 0.5f;

#ifdef BNB_VK_1
    var_uv.y = 1. - var_uv.y;
#endif
}
