#include <bnb/glsl.frag>

BNB_IN(0)
vec2 var_uv;

BNB_IN(1)
vec2 var_chameleon_uv;

BNB_DECLARE_SAMPLER_2D(0, 1, tex_eyelids_chameleon_color_0);
BNB_DECLARE_SAMPLER_2D(2, 3, tex_eyelids_chameleon_color_1);
BNB_DECLARE_SAMPLER_2D(4, 5, eyeshadows_smokey);
BNB_DECLARE_SAMPLER_2D(6, 7, tex_eyelids_chameleon);

void main()
{
    vec4 color_0 = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_eyelids_chameleon_color_0), var_uv);
    vec4 color_1 = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_eyelids_chameleon_color_1), var_uv);
    vec4 smokey = BNB_TEXTURE_2D(BNB_SAMPLER_2D(eyeshadows_smokey), var_uv);
    float eyelids_gloss = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_eyelids_chameleon), var_chameleon_uv).x;

    float smokey_mask = min(1.f, smokey.r + smokey.g + smokey.b);
    eyelids_gloss *= smokey_mask;

    vec4 result = mix(color_0, color_1, eyelids_gloss);

    bnb_FragColor = vec4(result.rgb, 1.f);
}
